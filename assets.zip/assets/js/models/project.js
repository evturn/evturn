var Project = Backbone.Model.extend({
	defaults: {
		summary: '',
		stack: '',
		lead: 'assets/img/evturn-winter-white.jpg',
		gallery: ['assets/img/ev-winter-white.jpg'],
		id: ''
	},
});
var Stack = Backbone.Model.extend({
	defaults: {
		image: '',
		technology: ''
	}
});